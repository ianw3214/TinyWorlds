INSPIRA

+====OVERVIEW=====+

Inspira is a game where the protagonist has an ability to enter other peoples minds like little "TINY WORLDS".

+=====INSTALLATION=====+

To play the game, extract the contents of the zip file and run the executable.

+=====CONTROLS=====+

MAIN MENU:
    - Up and Down arrow keys to navigate menu items
    - Space bar or enter to select the current menu item

GAMEPLAY:
    - Arrow keys to move character
    - Q and W keys to attack

Press escape at any time to quit the game.

+=====DESCRIPTION=====+

Inspira is a game where the protagonist has the ability to enter other peoples minds and live in their thoughts. In each level, the protagonist will discover that each person has different objects populating their minds, and that each person has a very different perspective of the world. The main goal of the game is to defeat the fears and nightmares that invade the minds of others.

+=====TOOLS=====+

CODE:
    - C++/SDL/SDL_Image/SDL_Mixer
    - Visual Studio Community Version 2015
ART:
    - Photoshop
MUSIC/SOUND:
    - BoscaCeoil
    - Chiptone

** Everything was created by Ian Wang, including art assets and music.
